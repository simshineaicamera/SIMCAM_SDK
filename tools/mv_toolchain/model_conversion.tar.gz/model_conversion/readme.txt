SimCamSDK now supports conversion of Caffe and Tensorflow models. Models base on other CNN frameworks, e.g. MXNet, Darknet(YOLO), PyTorch, etc. would need to convert to Caffe/Tensorflow first. This tool is similar to the conversion tool provided by NCSDK and modified based on NCSDK (Python).
The directory simcamtools has following structure.

simcamtools
   ── examples  # Caffe\TF conversion examples
   ── ncsdk-x86_64    # All necessary packeges and libs
   ── install-ncsdk.sh   # script to install all packeges and libs on your system, including caffe-ssd cpu version and tensorflow
   ── ncsdk.conf      # ncsdk config file
   ── requirments.txt       # python3 dependencies
   ── requirments_apt.txt   # ubuntu system dependencies
   ── readme.txt  # about the simcamtools
   ── uninstall-ncsdk.sh       # Uninstall
   ── version.txt       # version text
Setup
   Tested on Ubuntu 16.04, should work on other platforms
Just need to run "./install-ncsdk.sh" this command will install all tools on your system

Model conversion

mvNCCompile command converts caffe or tensorflow model to the graph.
Usage:

mvNCCompile network # network - *.prototxt(Caffe)* or *.meta(Tensorflow)*
-h                             # Show help
-w WEIGHTS                     # Model weight (Caffe only), *.caffemodel*
-in INPUTNODE                  # Name of input node, default: Caffe: *data*, TF: *input*
-on OUTPUTNODE                 # Name of output node, default: Caffe: Last layer, TF: *output*
-o OUTFILE                     # Output path of SimCam graph
-s NSHAVES                     # Number of Movidius Shave, recommend 6, default 1
-is INPUTSIZE INPUTSIZE        # Change network input size, default: original network size.
Example: run under simcamtools
mvNCCompile examples/caffe/deploy.prototxt -w examples/caffe/deploy.caffemodel -o examples/caffe/mobilenetssd.graph -s 6

